// const a =[1,2];
// console.log(a);

//    let b=[];
//       a.map(item=>{
//     b.push(item*2);
//    });
//    console.log(a);
//    console.log(b);

const a =[1,2];
console.log(a);
const b = [];
a.filter(item =>{
    b.push(item*2);
});
console.log(a);
console.log(b);

    

