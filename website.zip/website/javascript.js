/*write a javascript program to check two numbers
 and return true if one of the number is 100 
 or the sum of the two numbers is humdred */
//  let x=50;
//  let y=100;
//  let z=x+y;

// let myfun=(x,y)=>{
//     switch(100)
//     {
//         case x:
//             console.log('from my x');
//             return true;
//             break;

//             case y:
//                 console.log('from my y');
//                 return true;
//                 break;

//                 case x+y===100:
//                     console.log('from x+y');
//                     return true;
//                     break;

//                     default:
//                         console.log('enter correct number');
//                         break;
//     }

// };
// let result=myfun(10,10);
// console.log(result);

// let mystring='index.html.ss.ss.dd.ssg.venky';
// let  newarray =mystring.split(".");
// console.log(newarray);
// console.log(newarray.pop());

// let filename = (stringname)=>{
//     let  newarray =stringname.split(".");
//     console.log(newarray[1]);

// }
// filename("java.js");

// let a='a';
// a.replace(a.)

// const updatedString =str=> 
// str
// .split('')
// .map(item =>{
//         String.fromCharCode(item.charCodeAt(0) + 1))
// .join('');
// console.log(updatedString("veny"))

// const v = (str)=>{
//     if(str.startsWith('new!')){
//         console.log(str)
//     }else{
//         console.log('new!'+str)
//     }
// }
// v("venkymaheshburra");

// const mydate=(date=new date())=>{
//     console.log(date)
// }
// mydate();
// let mystring='ve.n.ky.html';
// let newstring=mystring.split('.');
// let arr=newstring.pop();
// console.log(arr);

// let mystring=myname=>{
//     let newstring=myname.split('.').pop();
//     console.log(newstring);
// }
// mystring('hello.css');

// let myfun=mystring=>{
//     if(mystring.endsWith('new!'))
//     {
//         console.log(mystring);
//     }
//     else{
//         console.log(mystring+'new!')
//     }
// };
// myfun('venky');

// let myfun=(name)=>
//     setTimeout(()=>{

//         console.log("hii");
//     },3000);
// }

// myfun("mahesh");


// Find the missing number in the given array:
// [8,2,5,1,4,7,6,9]

// Find the numbers which occur more than once:
// [2,3,4,2,5,6,4] 

//  Find the second largest number:
//   [31, 45, 13, 67, 58, 16, 59, 43, 61]

// let missing_number=(myarray)=>{

//     let min_value=Math.min(...myarray);

//     let max_value=Math.max(...myarray);

//     for(let i = min_value; i<=max_value; i++)
//     {
//         if(myarray.indexOf(i)<0)
//         {
//             console.log(i);  
            
//         }   
       
//     }

   
// };

// const num=[8,2,5,1,4,7,6,9];
// missing_number(num);



// Find the numbers which occur more than once:
//[2,3,4,2,5,6,4] 


// let myfun=(myarray)=>{

//        let newarra=new Set(myarray);
//        console.log(...newarra);
// };

// const num=[2,3,4,2,5,6,4];
// myfun(num);

// let myfun=(myarray)=>{
//     let duplicate_number=myarray.filter((num,index)=>{
//         return myarray.indexOf(num)!==index;
//     });

//     console.log(duplicate_number);

// }

// const numbers=[2,3,4,2,5,6,4];
// myfun(numbers);

// let myfun=(myarray)=>{

//     myarray.sort((a,b)=>{

//         return b-a;
//     });

//     console.log(myarray[1]);
// };

// const numbers=[31, 45, 13, 67, 58, 16, 59, 43, 61];

// myfun(numbers);


console.log("venky");